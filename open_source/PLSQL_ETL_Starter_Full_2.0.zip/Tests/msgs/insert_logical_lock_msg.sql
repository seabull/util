insert into app_msg (MSG_ID, APP_ID, MSG_CD, MSG, MSG_DESCR, MSG_SOLN)
values (101, 1, 'Logical Lock Held', 'Lock on @1@ already held by @2@. Try again in @3@ minutes.', 'Logical lock message.', '');

