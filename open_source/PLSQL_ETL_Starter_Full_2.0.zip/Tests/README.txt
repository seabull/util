The .tst files in this directory structure are Test Script files meant to be
run from within PL/SQL Developer.

The .ts files are Test Manager suite files, that run the .tst files in
order, gather output, and reports on the success/failure of each within
the Test Manager window of PL/SQL Developer. This provides a semi-decent
regression test suit that can be re-run any time a change is made to the
framework.

Open them in a text editor to view their contents. They can be converted
fairly easily to SQL*Plus scripts if you don't have licenses to PL/SQL Developer
(www.allroundautomations.com). By the way, I highly recommend PL/SQL Developer.
It barely beats TOAD in PL/SQL development features, and costs far less.
One license is under $200, but the costs decrease rapidly as you by in 
bulk. If you have a large organization, you can get an unlimited license
for about the same cost as six seats of TOAD.